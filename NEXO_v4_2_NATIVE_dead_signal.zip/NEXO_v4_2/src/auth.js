const crypto = require('crypto');
const { one, run } = require('./db');
const { parseCookies } = require('./utils');

const COOKIE = 'nexo_session';
const SESSION_DAYS = 30;

function hashToken(token) { return crypto.createHash('sha256').update(token).digest('hex'); }
function hashPassword(password, salt) { return crypto.scryptSync(password, salt, 64).toString('hex'); }
function makePassword(password) {
  const salt = crypto.randomBytes(16).toString('hex');
  return { salt, hash: hashPassword(password, salt) };
}
function verifyPassword(password, salt, expectedHex) {
  const actual = Buffer.from(hashPassword(password, salt), 'hex');
  const expected = Buffer.from(String(expectedHex || ''), 'hex');
  return actual.length === expected.length && actual.length > 0 && crypto.timingSafeEqual(actual, expected);
}
function newSession(userId) {
  const token = crypto.randomBytes(32).toString('hex');
  const hash = hashToken(token);
  const expires = new Date(Date.now() + SESSION_DAYS * 86400000).toISOString();
  run('INSERT INTO sessions(token_hash,user_id,expires_at) VALUES(?,?,?)', [hash, userId, expires]);
  return { token, expires };
}
function sessionCookie(token, secure = false) {
  return `${COOKIE}=${encodeURIComponent(token)}; HttpOnly; SameSite=Lax; Path=/; Max-Age=${SESSION_DAYS*86400}${secure ? '; Secure' : ''}`;
}
function clearCookie(secure = false) {
  return `${COOKIE}=; HttpOnly; SameSite=Lax; Path=/; Max-Age=0${secure ? '; Secure' : ''}`;
}
function getUser(req) {
  const token = parseCookies(req)[COOKIE];
  if (!token) return null;
  const row = one(`SELECT u.* FROM sessions s JOIN users u ON u.id=s.user_id WHERE s.token_hash=? AND s.expires_at>?`, [hashToken(token), new Date().toISOString()]);
  return row || null;
}
function deleteSession(req) {
  const token = parseCookies(req)[COOKIE];
  if (token) run('DELETE FROM sessions WHERE token_hash=?', [hashToken(token)]);
}
function cleanupSessions() { run('DELETE FROM sessions WHERE expires_at<=?', [new Date().toISOString()]); }
function isSecureRequest(req) { return String(req.headers['x-forwarded-proto'] || '').split(',')[0].trim() === 'https'; }
module.exports = { makePassword, verifyPassword, newSession, sessionCookie, clearCookie, getUser, deleteSession, cleanupSessions, isSecureRequest };
