const path = require('path');
const { one, all, run, tx } = require('./db');
const sse = require('./sse');
const U = require('./utils');

const lobbies = new Map();
const userLobby = new Map();
const invites = new Map();

const TILE = 64;
const COLS = 40;
const ROWS = 24;
const WORLD_W = COLS * TILE;
const WORLD_H = ROWS * TILE;
const PLAYER_R = 18;
const ENEMY_R = 18;
const MAX_PLAYERS = 6;

const LOOT = {
  scrap:   { name:'Scrap Bundle', value:20, weight:42 },
  battery: { name:'Power Battery', value:35, weight:28 },
  data:    { name:'Data Drive', value:55, weight:18 },
  gold:    { name:'Gold Module', value:90, weight:9 },
  crystal: { name:'Glitch Crystal', value:140, weight:3 }
};
const WEAPONS = {
  'pulse-pistol': { name:'Pulse Pistol', damage:24, range:300, cooldown:390, kind:'gun' },
  'scrap-rifle':  { name:'Scrap Rifle', damage:18, range:470, cooldown:210, kind:'gun' },
  'signal-sword': { name:'Signal Sword', damage:42, range:82, cooldown:470, kind:'melee' }
};
const UPGRADE_BASE = { backpack:120, speed:160, stamina:145, health:175 };
const UPGRADE_COLUMN = {
  backpack:'ds_backpack_level', speed:'ds_speed_level', stamina:'ds_stamina_level', health:'ds_health_level'
};

function pfp(row) { return row?.pfp_path ? `/media/pfp/${path.basename(row.pfp_path)}` : ''; }
function gameUser(row) { return { id:Number(row.id), username:row.username, pfp:pfp(row) }; }
function friends(a,b) { const low=Math.min(Number(a),Number(b)), high=Math.max(Number(a),Number(b)); return !!one('SELECT 1 FROM friendships WHERE user_low=? AND user_high=?',[low,high]); }
function makeCode(){
  const alphabet='ABCDEFGHJKLMNPQRSTUVWXYZ23456789';
  for(let tries=0;tries<30;tries++){
    let code=''; for(let i=0;i<5;i++)code+=alphabet[Math.floor(Math.random()*alphabet.length)];
    if(![...lobbies.values()].some(l=>l.code===code))return code;
  }
  return String(Date.now()).slice(-5);
}

function ensureProfile(userId){ run('INSERT OR IGNORE INTO game_profiles(user_id) VALUES(?)',[Number(userId)]); }
function profile(userId){
  ensureProfile(userId);
  const r=one('SELECT * FROM game_profiles WHERE user_id=?',[Number(userId)]);
  const levels={ backpack:Number(r.ds_backpack_level)||0, speed:Number(r.ds_speed_level)||0, stamina:Number(r.ds_stamina_level)||0, health:Number(r.ds_health_level)||0 };
  const stats={
    backpackSlots:4+levels.backpack*2,
    walkSpeed:185+levels.speed*11,
    sprintSpeed:260+levels.speed*13,
    maxStamina:100+levels.stamina*22,
    staminaRegen:22+levels.stamina*2.5,
    maxHealth:100+levels.health*18
  };
  const costs={};
  for(const k of Object.keys(UPGRADE_BASE)) costs[k]=Math.round(UPGRADE_BASE[k]*(1+levels[k]*0.72));
  return { cash:Number(r.dead_signal_cash)||0, levels, stats, costs };
}
function applyProfile(p){
  const pr=profile(p.id);
  p.cash=pr.cash; p.levels=pr.levels; p.stats=pr.stats;
  p.maxHealth=pr.stats.maxHealth;
  p.maxStamina=pr.stats.maxStamina;
  p.health=Math.min(Number(p.health)||p.maxHealth,p.maxHealth);
  p.stamina=Math.min(Number(p.stamina)||p.maxStamina,p.maxStamina);
  return pr;
}
function profileDto(userId){ return profile(userId); }

function lobbyPlayer(row){
  const p={
    id:Number(row.id), username:row.username, pfp:pfp(row), ready:false,
    input:{x:0,y:0,sprint:false}, lastInput:Date.now(),
    x:0,y:0,health:100,maxHealth:100,stamina:100,maxStamina:100,
    invulnUntil:0, downs:0, backpack:[], weapon:'pulse-pistol', attackAt:0,
    cash:0,levels:{},stats:{}
  };
  applyProfile(p); p.health=p.maxHealth; p.stamina=p.maxStamina;
  return p;
}
function playerSummary(p,lobby){
  const value=p.backpack.reduce((n,i)=>n+(Number(i.value)||0),0);
  return {
    id:p.id,username:p.username,pfp:p.pfp,ready:!!p.ready,host:p.id===lobby.hostId,
    cash:p.cash,backpackCount:p.backpack.length,backpackValue:value,backpackCapacity:p.stats.backpackSlots,
    weapon:p.weapon,levels:p.levels
  };
}
function lobbyDto(lobby){
  return {
    id:lobby.id,code:lobby.code,hostId:lobby.hostId,status:lobby.status,maxPlayers:MAX_PLAYERS,level:lobby.level,
    players:[...lobby.players.values()].map(p=>playerSummary(p,lobby)),
    chat:(lobby.chat||[]).slice(-40),lastLevel:lobby.lastLevel||null
  };
}
function findLobbyForUser(userId){ const id=userLobby.get(Number(userId)); return id?lobbies.get(id)||null:null; }
function broadcastLobby(lobby){ sse.sendMany([...lobby.players.keys()],'game_lobby',{lobby:lobbyDto(lobby)}); }
function addPlayer(lobby,row){
  if(lobby.players.size>=MAX_PLAYERS)throw Object.assign(new Error('Lobby is full.'),{status:409});
  const existing=findLobbyForUser(row.id);
  if(existing&&existing.id!==lobby.id)throw Object.assign(new Error('Leave your current lobby first.'),{status:409});
  if(!lobby.players.has(Number(row.id))){ lobby.players.set(Number(row.id),lobbyPlayer(row)); userLobby.set(Number(row.id),lobby.id); }
  return lobby.players.get(Number(row.id));
}
function removePlayer(lobby,userId){
  const id=Number(userId); lobby.players.delete(id); userLobby.delete(id);
  if(!lobby.players.size){ lobbies.delete(lobby.id); for(const [iid,inv] of invites)if(inv.lobbyId===lobby.id)invites.delete(iid); return; }
  if(lobby.hostId===id)lobby.hostId=lobby.players.keys().next().value;
  broadcastLobby(lobby);
}

function mulberry32(seed){ let a=seed>>>0; return ()=>{ a|=0;a=a+0x6D2B79F5|0;let t=Math.imul(a^a>>>15,1|a);t=t+Math.imul(t^t>>>7,61|t)^t;return((t^t>>>14)>>>0)/4294967296; }; }
function ri(rng,min,max){ return min+Math.floor(rng()*(max-min+1)); }
function shuffle(rng,arr){ for(let i=arr.length-1;i>0;i--){const j=Math.floor(rng()*(i+1));[arr[i],arr[j]]=[arr[j],arr[i]];} return arr; }
function center(room){ return {x:Math.floor(room.x+room.w/2),y:Math.floor(room.y+room.h/2)}; }
function carveRect(grid,x,y,w,h){ for(let yy=y;yy<y+h;yy++)for(let xx=x;xx<x+w;xx++)if(yy>0&&yy<ROWS-1&&xx>0&&xx<COLS-1)grid[yy][xx]=0; }
function carveCorridor(grid,a,b,rng){
  const horizontalFirst=rng()<.5;
  const h=(x1,x2,y)=>{const lo=Math.min(x1,x2),hi=Math.max(x1,x2);for(let x=lo;x<=hi;x++)carveRect(grid,x,y,1,2)};
  const v=(y1,y2,x)=>{const lo=Math.min(y1,y2),hi=Math.max(y1,y2);for(let y=lo;y<=hi;y++)carveRect(grid,x,y,2,1)};
  if(horizontalFirst){h(a.x,b.x,a.y);v(a.y,b.y,b.x)}else{v(a.y,b.y,a.x);h(a.x,b.x,b.y)}
}
function floorCells(grid){ const out=[]; for(let y=1;y<ROWS-1;y++)for(let x=1;x<COLS-1;x++)if(grid[y][x]===0)out.push({x,y}); return out; }
function cellPoint(c){ return {x:c.x*TILE+TILE/2,y:c.y*TILE+TILE/2}; }
function farEnough(c,from,minTiles=4){ return Math.hypot(c.x-from.x,c.y-from.y)>=minTiles; }
function chooseCells(rng,cells,count,avoid=[]){
  const pool=shuffle(rng,cells.filter(c=>avoid.every(a=>farEnough(c,a,3))).slice());
  return pool.slice(0,count);
}
function weightedLoot(rng){
  const total=Object.values(LOOT).reduce((n,x)=>n+x.weight,0); let v=rng()*total;
  for(const [id,d] of Object.entries(LOOT)){ v-=d.weight;if(v<=0)return{id,...d}; }
  return {id:'scrap',...LOOT.scrap};
}
function generateMap(level,seed){
  const rng=mulberry32(seed); const grid=Array.from({length:ROWS},()=>Array(COLS).fill(1)); const rooms=[];
  for(let attempt=0;attempt<180&&rooms.length<9;attempt++){
    const w=ri(rng,5,9),h=ri(rng,4,7),x=ri(rng,2,COLS-w-3),y=ri(rng,2,ROWS-h-3);
    if(rooms.some(r=>x<r.x+r.w+2&&x+w+2>r.x&&y<r.y+r.h+2&&y+h+2>r.y))continue;
    const room={x,y,w,h};rooms.push(room);carveRect(grid,x,y,w,h);
  }
  if(rooms.length<5){ // deterministic fallback layout
    const fallback=[{x:2,y:3,w:7,h:6},{x:13,y:3,w:7,h:6},{x:24,y:4,w:7,h:6},{x:8,y:14,w:8,h:6},{x:25,y:14,w:9,h:6}];
    for(const r of fallback){rooms.push(r);carveRect(grid,r.x,r.y,r.w,r.h)}
  }
  for(let i=1;i<rooms.length;i++)carveCorridor(grid,center(rooms[i-1]),center(rooms[i]),rng);
  if(rooms.length>4){carveCorridor(grid,center(rooms[0]),center(rooms[Math.floor(rooms.length/2)]),rng);carveCorridor(grid,center(rooms[2]),center(rooms[rooms.length-1]),rng)}
  const spawnCell=center(rooms[0]),exitCell=center(rooms[rooms.length-1]);
  const all=floorCells(grid),avoid=[spawnCell,exitCell];
  const enemyCount=Math.min(14,3+Math.floor(level*.8));
  const enemies=chooseCells(rng,all,enemyCount,avoid).map((c,i)=>{const p=cellPoint(c),hp=58+Math.min(level,30)*7;return{id:`e${i+1}`,x:p.x,y:p.y,hp,maxHp:hp,path:[],pathIndex:0,nextPathAt:0,attackAt:0};});
  const lootCount=Math.min(20,10+Math.floor(level*.55));
  const loot=chooseCells(rng,all,lootCount,[...avoid,...enemies.map(e=>({x:Math.floor(e.x/TILE),y:Math.floor(e.y/TILE)}))]).map((c,i)=>{const d=weightedLoot(rng),p=cellPoint(c);return{id:`l${i+1}`,type:d.id,name:d.name,value:d.value+Math.floor(level/5)*5,x:p.x,y:p.y};});
  const terminalCount=Math.min(4,2+Math.floor(level/7));
  const terminals=chooseCells(rng,all,terminalCount,avoid).map((c,i)=>({...cellPoint(c),id:`t${i+1}`,active:false}));
  const coreCount=Math.min(5,2+Math.floor(level/6));
  const cores=chooseCells(rng,all,coreCount,[...avoid,...terminals.map(t=>({x:Math.floor(t.x/TILE),y:Math.floor(t.y/TILE)}))]).map((c,i)=>({...cellPoint(c),id:`c${i+1}`,collected:false}));
  const weaponCount=Math.min(4,2+Math.floor(level/8));
  const weaponTypes=shuffle(rng,['pulse-pistol','scrap-rifle','signal-sword','scrap-rifle','signal-sword']);
  const weaponPickups=chooseCells(rng,all,weaponCount,avoid).map((c,i)=>({...cellPoint(c),id:`w${i+1}`,weapon:weaponTypes[i%weaponTypes.length],collected:false}));
  const taskKinds=shuffle(rng,['activate','recover','eliminate']).slice(0,2);
  const tasks=taskKinds.map((kind,i)=>{
    if(kind==='activate')return{id:`task${i}`,kind,label:'Restore terminals',progress:0,target:terminalCount};
    if(kind==='recover')return{id:`task${i}`,kind,label:'Recover signal cores',progress:0,target:coreCount};
    return{id:`task${i}`,kind,label:'Clear corrupted enemies',progress:0,target:Math.min(enemyCount,Math.max(2,2+Math.floor(level/2)))};
  });
  // Only place objective props that actually belong to this floor's task list.
  if(!taskKinds.includes('activate'))terminals.length=0;
  if(!taskKinds.includes('recover'))cores.length=0;
  return {
    seed,level,tileSize:TILE,cols:COLS,rows:ROWS,width:WORLD_W,height:WORLD_H,
    grid,tiles:grid.map(r=>r.map(v=>v?'#':'.').join('')),
    spawn:cellPoint(spawnCell),exit:{...cellPoint(exitCell),w:TILE*1.15,h:TILE*1.15},
    enemies,loot,terminals,cores,weaponPickups,tasks,kills:0,result:'',
    startedAt:Date.now(),endAt:Date.now()+360000,lastTick:Date.now(),lastBroadcast:0
  };
}

function circleHitsRect(x,y,r,rect){ const cx=Math.max(rect.x,Math.min(x,rect.x+rect.w)),cy=Math.max(rect.y,Math.min(y,rect.y+rect.h)),dx=x-cx,dy=y-cy; return dx*dx+dy*dy<r*r; }
function blockedCircle(world,x,y,r){
  if(x<r||y<r||x>world.width-r||y>world.height-r)return true;
  const minX=Math.max(0,Math.floor((x-r)/TILE)),maxX=Math.min(COLS-1,Math.floor((x+r)/TILE));
  const minY=Math.max(0,Math.floor((y-r)/TILE)),maxY=Math.min(ROWS-1,Math.floor((y+r)/TILE));
  for(let cy=minY;cy<=maxY;cy++)for(let cx=minX;cx<=maxX;cx++)if(world.grid[cy][cx]===1&&circleHitsRect(x,y,r,{x:cx*TILE,y:cy*TILE,w:TILE,h:TILE}))return true;
  return false;
}
function moveEntity(world,e,dx,dy,dist,r){
  if(!dx&&!dy)return; const mag=Math.hypot(dx,dy)||1; dx/=mag;dy/=mag;
  // 6px collision substeps prevent high-speed movement from tunneling through walls.
  const steps=Math.max(1,Math.ceil(Math.abs(dist)/6)),step=dist/steps;
  for(let i=0;i<steps;i++){
    const nx=e.x+dx*step;if(!blockedCircle(world,nx,e.y,r))e.x=nx;
    const ny=e.y+dy*step;if(!blockedCircle(world,e.x,ny,r))e.y=ny;
  }
}
function worldCell(x,y){return{x:Math.max(0,Math.min(COLS-1,Math.floor(x/TILE))),y:Math.max(0,Math.min(ROWS-1,Math.floor(y/TILE)))};}
function clearCell(world,x,y,r=ENEMY_R){
  if(x<0||y<0||x>=COLS||y>=ROWS||world.grid[y]?.[x]!==0)return false;
  const p=cellPoint({x,y});return !blockedCircle(world,p.x,p.y,r);
}
function unstickEntity(world,e,r){
  if(!blockedCircle(world,e.x,e.y,r))return false;
  const c=worldCell(e.x,e.y);
  for(let radius=0;radius<=4;radius++)for(let y=c.y-radius;y<=c.y+radius;y++)for(let x=c.x-radius;x<=c.x+radius;x++){
    if(!clearCell(world,x,y,r))continue;
    const p=cellPoint({x,y});e.x=p.x;e.y=p.y;return true;
  }
  return false;
}
function findPath(world,sx,sy,tx,ty){
  const start=worldCell(sx,sy),goal=worldCell(tx,ty),key=(x,y)=>y*COLS+x;
  if(!clearCell(world,goal.x,goal.y,ENEMY_R))return[];
  const q=[start],prev=new Int32Array(COLS*ROWS);prev.fill(-2);prev[key(start.x,start.y)]=-1;
  for(let qi=0;qi<q.length;qi++){
    const c=q[qi];if(c.x===goal.x&&c.y===goal.y)break;
    for(const [dx,dy] of [[1,0],[-1,0],[0,1],[0,-1]]){
      const nx=c.x+dx,ny=c.y+dy,k=key(nx,ny);
      if(nx<0||ny<0||nx>=COLS||ny>=ROWS||!clearCell(world,nx,ny,ENEMY_R)||prev[k]!==-2)continue;
      prev[k]=key(c.x,c.y);q.push({x:nx,y:ny});
    }
  }
  const gk=key(goal.x,goal.y);if(prev[gk]===-2)return[];
  const cells=[];let k=gk;while(k!==-1){cells.push({x:k%COLS,y:Math.floor(k/COLS)});k=prev[k];}cells.reverse();
  return cells.map(cellPoint);
}
function hasLineOfSight(world,a,b){
  const dx=b.x-a.x,dy=b.y-a.y,d=Math.hypot(dx,dy)||1,steps=Math.ceil(d/20);
  for(let i=1;i<steps;i++)if(blockedCircle(world,a.x+dx*i/steps,a.y+dy*i/steps,4))return false;
  return true;
}
function updateTasks(world){
  for(const t of world.tasks){
    if(t.kind==='activate')t.progress=world.terminals.filter(x=>x.active).length;
    else if(t.kind==='recover')t.progress=world.cores.filter(x=>x.collected).length;
    else if(t.kind==='eliminate')t.progress=Math.min(t.target,world.kills);
  }
}
function tasksDone(world){updateTasks(world);return world.tasks.every(t=>t.progress>=t.target);}

function startWorld(lobby){
  const seed=(Date.now()^Math.floor(Math.random()*0x7fffffff)^lobby.level*2654435761)>>>0;
  const world=generateMap(lobby.level,seed);lobby.world=world;lobby.status='running';lobby.lastLevel=null;
  let i=0;
  for(const p of lobby.players.values()){
    applyProfile(p);p.x=world.spawn.x+(i%3)*34;p.y=world.spawn.y+Math.floor(i/3)*34;p.input={x:0,y:0,sprint:false};p.health=p.maxHealth;p.stamina=p.maxStamina;p.invulnUntil=0;p.downs=0;i++;
  }
  broadcastLobby(lobby);snapshot(lobby,true);
}
function finishLevel(lobby,result){
  if(lobby.status!=='running'||!lobby.world)return;
  lobby.world.result=result;
  if(result==='cleared')lobby.level+=1;
  lobby.status='intermission';
  lobby.lastLevel={result,level:lobby.world.level,nextLevel:lobby.level,finishedAt:Date.now()};
  snapshot(lobby,true);
  const payload={lobbyId:lobby.id,result,level:lobby.world.level,nextLevel:lobby.level,players:[...lobby.players.values()].map(p=>playerSummary(p,lobby))};
  sse.sendMany([...lobby.players.keys()],result==='cleared'?'game_level_complete':'game_end',payload);
  broadcastLobby(lobby);
}
function snapshot(lobby,force=false){
  if(!lobby.world)return;const w=lobby.world,now=Date.now();if(!force&&now-w.lastBroadcast<100)return;w.lastBroadcast=now;updateTasks(w);
  const payload={
    lobbyId:lobby.id,status:lobby.status,result:w.result||'',level:w.level,width:w.width,height:w.height,tileSize:w.tileSize,tiles:w.tiles,spawn:w.spawn,exit:w.exit,
    timeLeft:Math.max(0,Math.ceil((w.endAt-now)/1000)),exitOpen:tasksDone(w),tasks:w.tasks,
    players:[...lobby.players.values()].map(p=>({id:p.id,username:p.username,pfp:p.pfp,x:+p.x.toFixed(1),y:+p.y.toFixed(1),health:+p.health.toFixed(1),maxHealth:p.maxHealth,stamina:+p.stamina.toFixed(1),maxStamina:p.maxStamina,invuln:p.invulnUntil>now,downs:p.downs,weapon:p.weapon,cash:p.cash,backpackCount:p.backpack.length,backpackValue:p.backpack.reduce((n,i)=>n+i.value,0),backpackCapacity:p.stats.backpackSlots})),
    loot:w.loot,terminals:w.terminals,cores:w.cores,weaponPickups:w.weaponPickups,
    enemies:w.enemies.map(e=>({id:e.id,x:+e.x.toFixed(1),y:+e.y.toFixed(1),hp:e.hp,maxHp:e.maxHp}))
  };
  sse.sendMany([...lobby.players.keys()],'game_state',payload);
}
function killEnemy(lobby,enemy,killer){
  const w=lobby.world;w.enemies=w.enemies.filter(e=>e.id!==enemy.id);w.kills++;
  if(Math.random()<.45){const d=weightedLoot(Math.random),id=`drop-${U.id()}`;w.loot.push({id,type:d.id,name:d.name,value:d.value+Math.floor(w.level/5)*5,x:enemy.x,y:enemy.y});}
  updateTasks(w);snapshot(lobby,true);
}
function tickLobby(lobby,now){
  if(lobby.status!=='running'||!lobby.world)return;const w=lobby.world,dt=Math.min(.1,Math.max(.001,(now-w.lastTick)/1000));w.lastTick=now;
  for(const p of lobby.players.values()){
    let dx=Number(p.input.x)||0,dy=Number(p.input.y)||0,mag=Math.hypot(dx,dy);if(mag>1){dx/=mag;dy/=mag;}
    const moving=mag>.05,sprinting=!!p.input.sprint&&moving&&p.stamina>1;
    const speed=sprinting?p.stats.sprintSpeed:p.stats.walkSpeed;
    if(sprinting)p.stamina=Math.max(0,p.stamina-30*dt);else p.stamina=Math.min(p.maxStamina,p.stamina+p.stats.staminaRegen*dt);
    moveEntity(w,p,dx,dy,speed*dt,PLAYER_R);
  }
  for(const enemy of w.enemies){
    // Safety net: enemies are never allowed to stay embedded in wall geometry.
    unstickEntity(w,enemy,ENEMY_R);
    let target=null,best=Infinity;for(const p of lobby.players.values()){const d=Math.hypot(p.x-enemy.x,p.y-enemy.y);if(d<best){best=d;target=p;}}
    if(!target)continue;
    if(now>=enemy.nextPathAt){enemy.path=findPath(w,enemy.x,enemy.y,target.x,target.y);enemy.pathIndex=Math.min(1,enemy.path.length-1);enemy.nextPathAt=now+550+Math.random()*250;}
    let aim=target;
    if(hasLineOfSight(w,enemy,target))aim=target;else if(enemy.path?.length){aim=enemy.path[Math.min(enemy.pathIndex,enemy.path.length-1)];if(Math.hypot(enemy.x-aim.x,enemy.y-aim.y)<20&&enemy.pathIndex<enemy.path.length-1)enemy.pathIndex++;}
    const dx=aim.x-enemy.x,dy=aim.y-enemy.y;moveEntity(w,enemy,dx,dy,(72+Math.min(45,w.level*2))*dt,ENEMY_R);
    const dist=Math.hypot(target.x-enemy.x,target.y-enemy.y);
    if(dist<42&&now>=enemy.attackAt&&target.invulnUntil<=now){
      enemy.attackAt=now+850;target.health-=12+Math.min(28,w.level*1.5);target.invulnUntil=now+700;
      if(target.health<=0){
        target.downs++;target.health=target.maxHealth;target.stamina=target.maxStamina;target.x=w.spawn.x;target.y=w.spawn.y;target.invulnUntil=now+1800;
        if(target.backpack.length){const item=target.backpack.pop();w.loot.push({...item,id:`drop-${U.id()}`,x:enemy.x,y:enemy.y});}
      }
    }
  }
  if(w.endAt<=now)finishLevel(lobby,'timeout');
  else if(tasksDone(w)){
    const allAtExit=[...lobby.players.values()].every(p=>Math.abs(p.x-w.exit.x)<w.exit.w/2&&Math.abs(p.y-w.exit.y)<w.exit.h/2);
    if(allAtExit)finishLevel(lobby,'cleared');
  }
  snapshot(lobby);
}

setInterval(()=>{const now=Date.now();for(const lobby of lobbies.values())tickLobby(lobby,now)},50).unref();
setInterval(()=>{
  for(const lobby of [...lobbies.values()])for(const id of [...lobby.players.keys()]){if(!sse.online(id))removePlayer(lobby,id);if(!lobbies.has(lobby.id))break;}
  const cutoff=Date.now()-120000;for(const [id,inv] of invites)if(inv.createdAt<cutoff||!lobbies.has(inv.lobbyId))invites.delete(id);
},30000).unref();

async function api(req,res,url,ctx){
  const {requireUser,responseJson}=ctx;if(!url.pathname.startsWith('/api/game/dead-signal'))return false;
  if(url.pathname==='/api/game/dead-signal/profile'&&req.method==='GET'){const user=requireUser(req,res);if(!user)return true;return responseJson(res,200,{profile:profileDto(user.id)});}
  if(url.pathname==='/api/game/dead-signal/upgrade'&&req.method==='POST'){
    const user=requireUser(req,res);if(!user)return true;const current=findLobbyForUser(user.id);if(current?.status==='running')return responseJson(res,409,{error:'Upgrade between levels, not during a run.'});
    const body=await U.readJsonBody(req),type=String(body.type||'');if(!UPGRADE_COLUMN[type])return responseJson(res,400,{error:'Unknown upgrade.'});
    try{
      const out=tx(()=>{const pr=profile(user.id),cost=pr.costs[type];if(pr.cash<cost)throw Object.assign(new Error('Not enough credits.'),{status:409});run(`UPDATE game_profiles SET dead_signal_cash=dead_signal_cash-?, ${UPGRADE_COLUMN[type]}=${UPGRADE_COLUMN[type]}+1 WHERE user_id=?`,[cost,user.id]);return profile(user.id);});
      const lobby=findLobbyForUser(user.id),p=lobby?.players.get(Number(user.id));if(p){applyProfile(p);broadcastLobby(lobby);}return responseJson(res,200,{profile:out});
    }catch(err){return responseJson(res,err.status||400,{error:err.message});}
  }
  if(url.pathname==='/api/game/dead-signal/status'&&req.method==='GET'){
    const user=requireUser(req,res);if(!user)return true;const lobby=findLobbyForUser(user.id);if(!lobby)return responseJson(res,200,{lobby:null,profile:profileDto(user.id)});return responseJson(res,200,{lobby:lobbyDto(lobby),state:lobby.world?stateDto(lobby):null,profile:profileDto(user.id)});
  }
  if(url.pathname==='/api/game/dead-signal/lobbies'&&req.method==='POST'){
    const user=requireUser(req,res);if(!user)return true;const existing=findLobbyForUser(user.id);if(existing)return responseJson(res,200,{lobby:lobbyDto(existing)});
    const id=U.id(),lobby={id,code:makeCode(),hostId:Number(user.id),status:'lobby',level:1,players:new Map(),world:null,chat:[],lastLevel:null,createdAt:Date.now()};lobby.players.set(Number(user.id),lobbyPlayer(user));userLobby.set(Number(user.id),id);lobbies.set(id,lobby);broadcastLobby(lobby);return responseJson(res,201,{lobby:lobbyDto(lobby)});
  }
  if(url.pathname==='/api/game/dead-signal/join-code'&&req.method==='POST'){
    const user=requireUser(req,res);if(!user)return true;const body=await U.readJsonBody(req),code=String(body.code||'').trim().toUpperCase(),lobby=[...lobbies.values()].find(l=>l.code===code);if(!lobby)return responseJson(res,404,{error:'Lobby code not found.'});if(!['lobby','intermission'].includes(lobby.status))return responseJson(res,409,{error:'That level is currently running.'});try{addPlayer(lobby,user)}catch(err){return responseJson(res,err.status||400,{error:err.message})}broadcastLobby(lobby);return responseJson(res,200,{lobby:lobbyDto(lobby)});
  }
  const inviteMatch=url.pathname.match(/^\/api\/game\/dead-signal\/lobbies\/([^/]+)\/invite$/);
  if(inviteMatch&&req.method==='POST'){
    const user=requireUser(req,res);if(!user)return true;const lobby=lobbies.get(inviteMatch[1]);if(!lobby||!lobby.players.has(Number(user.id)))return responseJson(res,404,{error:'Lobby not found.'});if(!['lobby','intermission'].includes(lobby.status))return responseJson(res,409,{error:'Invite friends between levels.'});
    const body=await U.readJsonBody(req),target=one('SELECT * FROM users WHERE username=? COLLATE NOCASE',[String(body.username||'').trim()]);if(!target)return responseJson(res,404,{error:'Friend not found.'});if(!friends(user.id,target.id))return responseJson(res,403,{error:'You can only invite friends.'});if(lobby.players.has(Number(target.id)))return responseJson(res,409,{error:'They are already here.'});
    const inviteId=U.id(),inv={id:inviteId,lobbyId:lobby.id,fromId:Number(user.id),toId:Number(target.id),createdAt:Date.now()};invites.set(inviteId,inv);sse.send(target.id,'game_invite',{inviteId,from:gameUser(user),lobby:lobbyDto(lobby)});return responseJson(res,201,{ok:true,inviteId});
  }
  const invResp=url.pathname.match(/^\/api\/game\/dead-signal\/invites\/([^/]+)\/respond$/);
  if(invResp&&req.method==='POST'){
    const user=requireUser(req,res);if(!user)return true;const inv=invites.get(invResp[1]);if(!inv||inv.toId!==Number(user.id))return responseJson(res,404,{error:'Invite expired.'});const body=await U.readJsonBody(req),action=String(body.action||'decline');invites.delete(inv.id);if(action!=='accept')return responseJson(res,200,{ok:true,accepted:false});const lobby=lobbies.get(inv.lobbyId);if(!lobby||!['lobby','intermission'].includes(lobby.status))return responseJson(res,409,{error:'That lobby is busy.'});try{addPlayer(lobby,user)}catch(err){return responseJson(res,err.status||400,{error:err.message})}broadcastLobby(lobby);return responseJson(res,200,{accepted:true,lobby:lobbyDto(lobby)});
  }
  const chatMatch=url.pathname.match(/^\/api\/game\/dead-signal\/lobbies\/([^/]+)\/chat$/);
  if(chatMatch&&req.method==='POST'){
    const user=requireUser(req,res);if(!user)return true;const lobby=lobbies.get(chatMatch[1]);if(!lobby||!lobby.players.has(Number(user.id)))return responseJson(res,404,{error:'Lobby not found.'});const body=await U.readJsonBody(req),text=String(body.text||'').trim().slice(0,240);if(!text)return responseJson(res,400,{error:'Message is empty.'});const message={id:U.id(),userId:Number(user.id),username:user.username,text,createdAt:new Date().toISOString()};lobby.chat.push(message);if(lobby.chat.length>60)lobby.chat.splice(0,lobby.chat.length-60);sse.sendMany([...lobby.players.keys()],'game_chat',{lobbyId:lobby.id,message});return responseJson(res,201,{message});
  }
  const readyMatch=url.pathname.match(/^\/api\/game\/dead-signal\/lobbies\/([^/]+)\/ready$/);
  if(readyMatch&&req.method==='POST'){
    const user=requireUser(req,res);if(!user)return true;const lobby=lobbies.get(readyMatch[1]),p=lobby?.players.get(Number(user.id));if(!lobby||!p)return responseJson(res,404,{error:'Lobby not found.'});if(!['lobby','intermission'].includes(lobby.status))return responseJson(res,409,{error:'Round already running.'});const body=await U.readJsonBody(req);p.ready=typeof body.ready==='boolean'?body.ready:!p.ready;broadcastLobby(lobby);return responseJson(res,200,{lobby:lobbyDto(lobby)});
  }
  const startMatch=url.pathname.match(/^\/api\/game\/dead-signal\/lobbies\/([^/]+)\/start$/);
  if(startMatch&&req.method==='POST'){
    const user=requireUser(req,res);if(!user)return true;const lobby=lobbies.get(startMatch[1]);if(!lobby||lobby.hostId!==Number(user.id))return responseJson(res,403,{error:'Only the host can start the level.'});if(!['lobby','intermission'].includes(lobby.status))return responseJson(res,409,{error:'A level is already running.'});startWorld(lobby);return responseJson(res,200,{lobby:lobbyDto(lobby),state:stateDto(lobby)});
  }
  const sellMatch=url.pathname.match(/^\/api\/game\/dead-signal\/lobbies\/([^/]+)\/sell$/);
  if(sellMatch&&req.method==='POST'){
    const user=requireUser(req,res);if(!user)return true;const lobby=lobbies.get(sellMatch[1]),p=lobby?.players.get(Number(user.id));if(!lobby||!p)return responseJson(res,404,{error:'Lobby not found.'});if(lobby.status==='running')return responseJson(res,409,{error:'Sell loot between levels.'});const earned=p.backpack.reduce((n,i)=>n+(Number(i.value)||0),0);if(earned>0)run('UPDATE game_profiles SET dead_signal_cash=dead_signal_cash+? WHERE user_id=?',[earned,user.id]);p.backpack=[];applyProfile(p);broadcastLobby(lobby);return responseJson(res,200,{earned,profile:profileDto(user.id),lobby:lobbyDto(lobby)});
  }
  const leaveMatch=url.pathname.match(/^\/api\/game\/dead-signal\/lobbies\/([^/]+)\/leave$/);
  if(leaveMatch&&req.method==='POST'){const user=requireUser(req,res);if(!user)return true;const lobby=lobbies.get(leaveMatch[1]);if(lobby?.players.has(Number(user.id)))removePlayer(lobby,user.id);return responseJson(res,200,{ok:true});}
  const inputMatch=url.pathname.match(/^\/api\/game\/dead-signal\/lobbies\/([^/]+)\/input$/);
  if(inputMatch&&req.method==='POST'){
    const user=requireUser(req,res);if(!user)return true;const lobby=lobbies.get(inputMatch[1]),p=lobby?.players.get(Number(user.id));if(!lobby||!p||lobby.status!=='running')return responseJson(res,409,{error:'Level is not running.'});const body=await U.readJsonBody(req);p.input.x=Math.max(-1,Math.min(1,Number(body.x)||0));p.input.y=Math.max(-1,Math.min(1,Number(body.y)||0));p.input.sprint=!!body.sprint;p.lastInput=Date.now();return responseJson(res,200,{ok:true});
  }
  const interactMatch=url.pathname.match(/^\/api\/game\/dead-signal\/lobbies\/([^/]+)\/interact$/);
  if(interactMatch&&req.method==='POST'){
    const user=requireUser(req,res);if(!user)return true;const lobby=lobbies.get(interactMatch[1]),p=lobby?.players.get(Number(user.id));if(!lobby||!p||lobby.status!=='running')return responseJson(res,409,{error:'Level is not running.'});const w=lobby.world;
    const near=(arr,filter=()=>true)=>arr.filter(filter).map(o=>({o,d:Math.hypot(p.x-o.x,p.y-o.y)})).filter(x=>x.d<76).sort((a,b)=>a.d-b.d)[0]?.o;
    const loot=near(w.loot);if(loot){if(p.backpack.length>=p.stats.backpackSlots)return responseJson(res,409,{error:'Backpack full. Sell loot between levels or upgrade Backpack Space.'});p.backpack.push({id:loot.id,type:loot.type,name:loot.name,value:loot.value});w.loot=w.loot.filter(x=>x.id!==loot.id);snapshot(lobby,true);return responseJson(res,200,{action:'loot',item:loot});}
    const wp=near(w.weaponPickups,x=>!x.collected);if(wp){wp.collected=true;p.weapon=wp.weapon;snapshot(lobby,true);return responseJson(res,200,{action:'weapon',weapon:wp.weapon});}
    const term=near(w.terminals,x=>!x.active);if(term){term.active=true;updateTasks(w);snapshot(lobby,true);return responseJson(res,200,{action:'terminal'});}
    const core=near(w.cores,x=>!x.collected);if(core){core.collected=true;updateTasks(w);snapshot(lobby,true);return responseJson(res,200,{action:'core'});}
    return responseJson(res,200,{action:'none'});
  }
  const attackMatch=url.pathname.match(/^\/api\/game\/dead-signal\/lobbies\/([^/]+)\/attack$/);
  if(attackMatch&&req.method==='POST'){
    const user=requireUser(req,res);if(!user)return true;const lobby=lobbies.get(attackMatch[1]),p=lobby?.players.get(Number(user.id));if(!lobby||!p||lobby.status!=='running')return responseJson(res,409,{error:'Level is not running.'});const w=lobby.world,weapon=WEAPONS[p.weapon]||WEAPONS['pulse-pistol'],now=Date.now();if(now<p.attackAt)return responseJson(res,200,{ok:true,cooldown:true});p.attackAt=now+weapon.cooldown;
    const body=await U.readJsonBody(req);let dx=Number(body.x)||0,dy=Number(body.y)||0;
    if(Math.hypot(dx,dy)<.1){let best=null,dist=Infinity;for(const e of w.enemies){const d=Math.hypot(e.x-p.x,e.y-p.y);if(d<dist){best=e;dist=d;}}if(best){dx=best.x-p.x;dy=best.y-p.y;}else{dx=1;dy=0;}}
    const mag=Math.hypot(dx,dy)||1;dx/=mag;dy/=mag;let hit=null,end={x:p.x+dx*weapon.range,y:p.y+dy*weapon.range};
    if(weapon.kind==='melee'){
      let best=weapon.range+1;for(const e of w.enemies){const ex=e.x-p.x,ey=e.y-p.y,d=Math.hypot(ex,ey);if(d>weapon.range)continue;const dot=(ex/d)*dx+(ey/d)*dy;if(dot>.05&&d<best){best=d;hit=e;}}if(hit)end={x:hit.x,y:hit.y};
    }else{
      for(let d=14;d<=weapon.range;d+=14){const x=p.x+dx*d,y=p.y+dy*d;if(blockedCircle(w,x,y,3)){end={x,y};break;}const found=w.enemies.find(e=>Math.hypot(e.x-x,e.y-y)<ENEMY_R+6);if(found){hit=found;end={x:found.x,y:found.y};break;}}
    }
    if(hit){hit.hp-=weapon.damage;if(hit.hp<=0)killEnemy(lobby,hit,p);}
    sse.sendMany([...lobby.players.keys()],'game_attack',{lobbyId:lobby.id,fromId:p.id,weapon:p.weapon,x1:p.x,y1:p.y,x2:end.x,y2:end.y,hitId:hit?.id||''});snapshot(lobby,true);return responseJson(res,200,{ok:true,hit:!!hit,enemyHp:hit?Math.max(0,hit.hp):null});
  }
  return false;
}

function stateDto(lobby){
  if(!lobby.world)return null;const w=lobby.world,now=Date.now();updateTasks(w);return {
    lobbyId:lobby.id,status:lobby.status,result:w.result||'',level:w.level,width:w.width,height:w.height,tileSize:w.tileSize,tiles:w.tiles,spawn:w.spawn,exit:w.exit,timeLeft:Math.max(0,Math.ceil((w.endAt-now)/1000)),exitOpen:tasksDone(w),tasks:w.tasks,
    players:[...lobby.players.values()].map(p=>({id:p.id,username:p.username,pfp:p.pfp,x:p.x,y:p.y,health:p.health,maxHealth:p.maxHealth,stamina:p.stamina,maxStamina:p.maxStamina,invuln:p.invulnUntil>now,downs:p.downs,weapon:p.weapon,cash:p.cash,backpackCount:p.backpack.length,backpackValue:p.backpack.reduce((n,i)=>n+i.value,0),backpackCapacity:p.stats.backpackSlots})),loot:w.loot,terminals:w.terminals,cores:w.cores,weaponPickups:w.weaponPickups,enemies:w.enemies.map(e=>({id:e.id,x:e.x,y:e.y,hp:e.hp,maxHp:e.maxHp}))
  };
}

module.exports={api,lobbyDto,stateDto,_test:{lobbies,invites,userLobby,generateMap,blockedCircle,findPath,moveEntity,unstickEntity,clearCell,TILE,COLS,ROWS}};
