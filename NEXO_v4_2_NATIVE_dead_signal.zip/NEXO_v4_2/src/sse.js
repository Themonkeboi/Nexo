const clients = new Map();
const presence = new Map();

function touch(userId) { if (userId) presence.set(Number(userId), Date.now()); }
function online(userId) { return Date.now() - (presence.get(Number(userId)) || 0) < 70000; }
function onlineCount() {
  const now = Date.now(); let n = 0;
  for (const [id, t] of presence) { if (now - t < 70000) n++; else presence.delete(id); }
  return n;
}
function connect(req, res, user) {
  res.writeHead(200, {
    'Content-Type':'text/event-stream', 'Cache-Control':'no-cache, no-transform',
    'Connection':'keep-alive', 'X-Accel-Buffering':'no'
  });
  res.write(`event: ready\ndata: ${JSON.stringify({ok:true})}\n\n`);
  const id = Number(user.id);
  touch(id);
  if (!clients.has(id)) clients.set(id, new Set());
  clients.get(id).add(res);
  const timer = setInterval(() => { touch(id); try { res.write(': ping\n\n'); } catch {} }, 25000);
  req.on('close', () => {
    clearInterval(timer);
    clients.get(id)?.delete(res);
    if (!clients.get(id)?.size) clients.delete(id);
  });
}
function send(userId, event, payload) {
  const set = clients.get(Number(userId));
  if (!set) return;
  const chunk = `event: ${event}\ndata: ${JSON.stringify(payload)}\n\n`;
  for (const res of set) { try { res.write(chunk); } catch {} }
}
function sendMany(ids, event, payload) { for (const id of new Set(ids.map(Number))) send(id, event, payload); }
module.exports = { connect, send, sendMany, touch, online, onlineCount };
