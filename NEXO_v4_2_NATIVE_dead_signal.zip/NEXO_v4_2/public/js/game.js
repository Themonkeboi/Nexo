import{$,esc,avatar,toast}from'./ui.js';
import{api}from'./api.js';
import{state}from'./state.js';

const WEAPON_NAMES={'pulse-pistol':'Pulse Pistol','scrap-rifle':'Scrap Rifle','signal-sword':'Signal Sword'};
const UPGRADE_INFO={
  backpack:{name:'Backpack Space',desc:'+2 loot slots each level'},
  speed:{name:'Speed',desc:'Move and sprint faster'},
  stamina:{name:'Stamina',desc:'More sprint energy + regen'},
  health:{name:'Health',desc:'+18 max health each level'}
};
const ASSET_PATH={
  floor:'/assets/dead-signal/textures/floor.png',
  floor2:'/assets/dead-signal/textures/floor-2.png',
  floor3:'/assets/dead-signal/textures/floor-3.png',
  wall:'/assets/dead-signal/textures/wall.png',
  wall2:'/assets/dead-signal/textures/wall-2.png',
  enemy:'/assets/dead-signal/textures/enemy.png',terminal:'/assets/dead-signal/textures/terminal.png',core:'/assets/dead-signal/textures/core.png',exit:'/assets/dead-signal/textures/exit.png',
  scrap:'/assets/dead-signal/textures/loot-scrap.png',battery:'/assets/dead-signal/textures/loot-battery.png',data:'/assets/dead-signal/textures/loot-data.png',gold:'/assets/dead-signal/textures/loot-gold.png',crystal:'/assets/dead-signal/textures/loot-crystal.png',
  'pulse-pistol':'/assets/dead-signal/textures/weapon-pistol.png','scrap-rifle':'/assets/dead-signal/textures/weapon-rifle.png','signal-sword':'/assets/dead-signal/textures/weapon-sword.png'
};
const images=new Map(),pfpImages=new Map();
for(const [k,src] of Object.entries(ASSET_PATH)){const im=new Image();im.src=src;images.set(k,im)}

let lobby=null,snapshot=null,profile=null,invite=null;
let input={x:0,y:0,sprint:false},keyboard={},inputTimer=null,raf=0,inputBusy=false,joystickPointer=null,mobileSprint=false;
let displayPlayers=new Map(),chatCollapsed=false,aim={x:1,y:0},effects=[],lastRenderedLevel=0;
const canvas=()=>$('#deadSignalCanvas'),ctx=()=>canvas()?.getContext('2d');

function setGameMode(mode){
  $('#gamesLibrary').classList.toggle('hidden',mode!=='library');
  $('#deadSignalHub').classList.toggle('hidden',mode!=='hub');
  $('#deadSignalLobby').classList.toggle('hidden',mode!=='lobby');
  $('#deadSignalIntermission').classList.toggle('hidden',mode!=='intermission');
  $('#deadSignalStage').classList.toggle('hidden',mode!=='running');
}
function lobbyPlayer(id){return lobby?.players.find(p=>p.id===id)}
function isHost(){return !!(lobby&&state.user&&lobby.hostId===state.user.id)}
function money(v){return '$'+Math.max(0,Math.round(Number(v)||0)).toLocaleString()}
function pfpMarkup(p,cls='ds-lobby-pfp'){return avatar(p,cls)}

async function loadProfile(){
  if(!state.user)return;
  try{profile=(await api('/api/game/dead-signal/profile')).profile;renderProgression()}catch(e){console.error(e)}
}
function effectText(type){
  if(!profile)return'';const l=profile.levels[type]||0,s=profile.stats;
  if(type==='backpack')return `${s.backpackSlots} slots`;
  if(type==='speed')return `${Math.round(s.walkSpeed)} walk / ${Math.round(s.sprintSpeed)} sprint`;
  if(type==='stamina')return `${Math.round(s.maxStamina)} stamina`;
  return `${Math.round(s.maxHealth)} max HP`;
}
function upgradeShopHTML(){
  if(!profile)return'<div class="muted small">Loading upgrades…</div>';
  return Object.entries(UPGRADE_INFO).map(([id,u])=>`<button class="ds-upgrade-card" data-upgrade="${id}"><span class="ds-upgrade-name">${esc(u.name)} <b>Lv.${profile.levels[id]||0}</b></span><span class="ds-upgrade-effect">${esc(effectText(id))}</span><span class="ds-upgrade-bottom"><small>${esc(u.desc)}</small><strong>${money(profile.costs[id])}</strong></span></button>`).join('');
}
function renderProgression(){
  const cash=profile?.cash??lobbyPlayer(state.user?.id)?.cash??0;
  if($('#dsLobbyCash'))$('#dsLobbyCash').textContent=money(cash);
  if($('#dsIntermissionCash'))$('#dsIntermissionCash').textContent=money(cash);
  for(const id of ['dsLobbyUpgradeShop','dsIntermissionUpgradeShop']){
    const box=$('#'+id);if(!box)continue;box.innerHTML=upgradeShopHTML();
    box.querySelectorAll('[data-upgrade]').forEach(b=>b.onclick=()=>buyUpgrade(b.dataset.upgrade));
  }
}
async function buyUpgrade(type){
  try{const d=await api('/api/game/dead-signal/upgrade',{method:'POST',body:JSON.stringify({type})});profile=d.profile;renderProgression();toast(`${UPGRADE_INFO[type].name} upgraded`)}catch(e){toast(e.message)}
}
async function sellLoot(){
  if(!lobby)return;
  try{const d=await api(`/api/game/dead-signal/lobbies/${lobby.id}/sell`,{method:'POST',body:'{}'});profile=d.profile;lobby=d.lobby;renderProgression();renderLobby();toast(d.earned?`Sold haul for ${money(d.earned)}`:'Backpack is empty')}catch(e){toast(e.message)}
}

function renderLobbyPads(){
  const box=$('#dsLobbyPads');if(!box)return;box.innerHTML='';
  for(let i=0;i<6;i++){
    const p=lobby?.players?.[i],pad=document.createElement('div');
    pad.className='ds-pad-slot'+(p?' occupied':' empty')+(p?.id===state.user?.id?' local':'');
    if(p){pad.innerHTML=`<div class="ds-pfp-character">${pfpMarkup(p,'ds-lobby-pfp')}<div class="ds-pfp-glitch"></div></div><div class="ds-pad-glow"></div><div class="ds-pad-base"></div><div class="ds-pad-name">${p.host?'<span class="ds-host-crown">HOST</span>':''}<b>${esc(p.username)}</b><span>${p.ready?'READY':'IN LOBBY'} · ${money(p.cash)}</span></div>`}
    else pad.innerHTML='<div class="ds-empty-character">+</div><div class="ds-pad-glow"></div><div class="ds-pad-base"></div><div class="ds-pad-name"><b>Open Slot</b><span>INVITE A FRIEND</span></div>';
    box.appendChild(pad);
  }
}
function renderInviteFriends(){
  const box=$('#dsFriendInvites');if(!box)return;box.innerHTML='';const inLobby=new Set((lobby?.players||[]).map(p=>p.username.toLowerCase()));const available=(state.friends||[]).filter(f=>!inLobby.has(f.username.toLowerCase()));
  if(!available.length){box.innerHTML='<div class="muted small">No other friends available right now.</div>';return}
  available.forEach(f=>{const row=document.createElement('div');row.className='ds-friend-row';row.innerHTML=`${avatar(f)}<div class="ds-player-meta"><b>${esc(f.username)}</b><span>${f.online?'Online':'Offline'}</span></div><button class="secondary">Invite</button>`;row.querySelector('button').onclick=async()=>{try{await api(`/api/game/dead-signal/lobbies/${lobby.id}/invite`,{method:'POST',body:JSON.stringify({username:f.username})});row.querySelector('button').textContent='Invited';row.querySelector('button').disabled=true;toast('Game invite sent')}catch(e){toast(e.message)}};box.appendChild(row)});
}
function renderIntermission(){
  stopInputLoop();setGameMode('intermission');const me=lobbyPlayer(state.user?.id),last=lobby.lastLevel||{};
  $('#dsIntermissionTitle').textContent=last.result==='timeout'?`Floor ${last.level||lobby.level} failed`:`Floor ${last.level||Math.max(1,lobby.level-1)} cleared`;
  $('#dsIntermissionText').textContent=last.result==='timeout'?'The connection timed out. Your backpack is still yours — sell, upgrade, and retry.':'Your haul made it back. Sell it now, buy permanent upgrades, then let the host generate the next floor.';
  $('#dsIntermissionLevel').textContent=String(lobby.level||1);$('#dsIntermissionBag').textContent=`${me?.backpackCount||0} / ${me?.backpackCapacity||profile?.stats?.backpackSlots||4}`;
  const sellValue=me?.backpackValue||0;$('#dsSellBtn').textContent=sellValue?`SELL BACKPACK · ${money(sellValue)}`:'BACKPACK EMPTY';$('#dsSellBtn').disabled=!sellValue;
  $('#dsNextLevelBtn').classList.toggle('hidden',!isHost());$('#dsNextLevelBtn').textContent=last.result==='timeout'?`HOST: RETRY FLOOR ${lobby.level}`:`HOST: START FLOOR ${lobby.level}`;
  $('#dsIntermissionHint').textContent=isHost()?'You control when the squad continues.':'Buy upgrades while you wait for the host.';renderProgression();renderChatMessages();
}
function renderLobby(){
  if(!lobby){setGameMode('library');return}
  if(lobby.status==='intermission'){renderIntermission();return}
  if(lobby.status==='running'){setGameMode('running');return}
  setGameMode('lobby');$('#dsLobbyCode').textContent=lobby.code;$('#dsLobbyCount').textContent=`${lobby.players.length}/${lobby.maxPlayers} connected`;$('#dsReadySummary').textContent=`${lobby.players.filter(p=>p.ready).length} ready`;
  const players=$('#dsLobbyPlayers');players.innerHTML='';lobby.players.forEach(p=>{const e=document.createElement('div');e.className='ds-player-card';e.innerHTML=`${pfpMarkup(p,'ds-mini-pfp')}<div class="ds-player-meta"><b>${esc(p.username)}</b><span>${p.host?'Host · ':''}Bag ${p.backpackCount}/${p.backpackCapacity}</span></div><div class="ds-ready-chip ${p.ready?'ready':''}">${p.ready?'READY':'WAITING'}</div>`;players.appendChild(e)});
  const me=lobbyPlayer(state.user?.id);$('#dsReadyBtn').textContent=me?.ready?'Unready':'Mark Ready';$('#dsStartBtn').classList.toggle('hidden',!isHost());$('#dsStartBtn').textContent=`START LEVEL ${lobby.level||1}`;$('#dsStartHint').textContent=isHost()?'You are the host. Start whenever the squad is ready.':'Waiting for the host to start the level.';
  const value=me?.backpackValue||0;$('#dsSellBtnLobby').textContent=value?`Sell Backpack · ${money(value)}`:'Backpack Empty';$('#dsSellBtnLobby').disabled=!value;
  renderLobbyPads();renderInviteFriends();renderProgression();
}

function showInvite(data){invite=data;$('#dsInviteText').textContent=`${data.from.username} invited you to DEAD SIGNAL (${data.lobby.players.length}/${data.lobby.maxPlayers})`;$('#dsInviteOverlay').classList.remove('hidden')}
async function respondInvite(action){if(!invite)return;const id=invite.inviteId;$('#dsInviteOverlay').classList.add('hidden');try{const d=await api(`/api/game/dead-signal/invites/${id}/respond`,{method:'POST',body:JSON.stringify({action})});if(d.accepted){lobby=d.lobby;renderLobby();window.dispatchEvent(new CustomEvent('nexo:view',{detail:'games'}))}}catch(e){toast(e.message)}finally{invite=null}}
async function loadStatus(){if(!state.user)return;try{const d=await api('/api/game/dead-signal/status');lobby=d.lobby||null;snapshot=d.state||null;profile=d.profile||profile;renderProgression();renderLobby();if(snapshot&&lobby?.status==='running')enterRunning(snapshot)}catch(e){console.error(e)}}
async function createLobby(){try{const d=await api('/api/game/dead-signal/lobbies',{method:'POST',body:'{}'});lobby=d.lobby;await loadProfile();renderLobby()}catch(e){toast(e.message)}}
async function joinCode(){const code=$('#dsJoinCode').value.trim();if(!code)return;try{const d=await api('/api/game/dead-signal/join-code',{method:'POST',body:JSON.stringify({code})});lobby=d.lobby;await loadProfile();renderLobby();toast('Joined lobby')}catch(e){toast(e.message)}}
async function toggleReady(){if(!lobby)return;const me=lobbyPlayer(state.user.id);try{const d=await api(`/api/game/dead-signal/lobbies/${lobby.id}/ready`,{method:'POST',body:JSON.stringify({ready:!me?.ready})});lobby=d.lobby;renderLobby()}catch(e){toast(e.message)}}
async function startGame(){if(!lobby||!isHost())return;try{const d=await api(`/api/game/dead-signal/lobbies/${lobby.id}/start`,{method:'POST',body:'{}'});lobby=d.lobby;snapshot=d.state;enterRunning(snapshot)}catch(e){toast(e.message)}}
async function leaveLobby(){if(!lobby)return;const id=lobby.id;try{await api(`/api/game/dead-signal/lobbies/${id}/leave`,{method:'POST',body:'{}'})}catch{}lobby=null;snapshot=null;stopInputLoop();setGameMode('library')}

function renderChatMessages(){const box=$('#dsGameChatMessages');if(!box)return;box.innerHTML='';for(const m of (lobby?.chat||[]).slice(-30)){const row=document.createElement('div');row.className='ds-game-chat-row'+(m.userId===state.user?.id?' mine':'');row.innerHTML=`<b>${esc(m.username)}</b><span>${esc(m.text)}</span>`;box.appendChild(row)}requestAnimationFrame(()=>box.scrollTop=box.scrollHeight)}
function appendGameChat(data){if(!lobby||data.lobbyId!==lobby.id)return;lobby.chat=lobby.chat||[];if(!lobby.chat.some(x=>x.id===data.message.id))lobby.chat.push(data.message);renderChatMessages()}
async function sendGameChat(text){text=String(text||'').trim();if(!text||!lobby)return;try{const d=await api(`/api/game/dead-signal/lobbies/${lobby.id}/chat`,{method:'POST',body:JSON.stringify({text})});appendGameChat({lobbyId:lobby.id,message:d.message})}catch(e){toast(e.message)}}

function enterRunning(s){if(s?.level!==lastRenderedLevel){displayPlayers.clear();effects=[];lastRenderedLevel=s?.level||0}snapshot=s;setGameMode('running');startInputLoop();resizeCanvas();renderHUD();renderChatMessages();$('#dsResult').classList.add('hidden')}
function showLevelResult(data){const cleared=data.result==='cleared';$('#dsResultTitle').textContent=cleared?'FLOOR COMPLETE':'CONNECTION LOST';$('#dsResultText').textContent=cleared?`Floor ${data.level} cleared. Sell your haul and upgrade before floor ${data.nextLevel}.`:'Time ran out. Regroup, upgrade, and retry.';$('#dsResult').classList.remove('hidden');setTimeout(()=>$('#dsResult').classList.add('hidden'),4500)}
function keysToInput(){let x=0,y=0;if(keyboard.KeyA||keyboard.ArrowLeft)x--;if(keyboard.KeyD||keyboard.ArrowRight)x++;if(keyboard.KeyW||keyboard.ArrowUp)y--;if(keyboard.KeyS||keyboard.ArrowDown)y++;if(x||y){const m=Math.hypot(x,y);x/=m;y/=m}if(joystickPointer===null){input.x=x;input.y=y}input.sprint=!!(keyboard.ShiftLeft||keyboard.ShiftRight||mobileSprint)}
function sendInput(){if(!lobby||!snapshot||snapshot.status!=='running'||inputBusy)return;inputBusy=true;fetch(`/api/game/dead-signal/lobbies/${encodeURIComponent(lobby.id)}/input`,{method:'POST',credentials:'include',headers:{'Content-Type':'application/json'},body:JSON.stringify(input)}).catch(()=>{}).finally(()=>inputBusy=false)}
function startInputLoop(){if(!inputTimer)inputTimer=setInterval(sendInput,85)}function stopInputLoop(){if(inputTimer){clearInterval(inputTimer);inputTimer=null}input={x:0,y:0,sprint:false}}
async function interact(){if(!lobby||!snapshot)return;try{const d=await api(`/api/game/dead-signal/lobbies/${lobby.id}/interact`,{method:'POST',body:'{}'});if(d.action==='loot')toast(`Grabbed ${d.item.name} · ${money(d.item.value)}`);else if(d.action==='weapon')toast(`Equipped ${WEAPON_NAMES[d.weapon]||d.weapon}`);else if(d.action==='terminal')toast('Terminal restored');else if(d.action==='core')toast('Signal core recovered')}catch(e){toast(e.message)}}
async function attack(auto=false){if(!lobby||!snapshot)return;const body=auto?{x:0,y:0}:{x:aim.x,y:aim.y};try{await api(`/api/game/dead-signal/lobbies/${lobby.id}/attack`,{method:'POST',body:JSON.stringify(body)})}catch{}}

function resizeCanvas(){const c=canvas();if(!c)return;const r=c.getBoundingClientRect(),dpr=Math.min(2,devicePixelRatio||1),w=Math.max(320,Math.floor(r.width*dpr)),h=Math.max(180,Math.floor(r.height*dpr));if(c.width!==w||c.height!==h){c.width=w;c.height=h}}
function worldToScreen(x,y,camX,camY,scale,w,h){return{x:(x-camX)*scale+w/2,y:(y-camY)*scale+h/2}}
function pfpImage(url){if(!url)return null;if(!pfpImages.has(url)){const im=new Image();im.src=url;pfpImages.set(url,im)}return pfpImages.get(url)}
function drawPfpCharacter(g,p,x,y,size,local=false){
  g.save();g.translate(Math.round(x),Math.round(y));if(p.invuln&&Math.floor(Date.now()/100)%2===0)g.globalAlpha=.35;g.fillStyle='#0008';g.beginPath();g.ellipse(0,size*.55,size*.66,size*.22,0,0,Math.PI*2);g.fill();
  const r=size*.64;g.save();g.beginPath();g.arc(0,0,r,0,Math.PI*2);g.clip();const im=pfpImage(p.pfp);if(im?.complete&&im.naturalWidth)g.drawImage(im,-r,-r,r*2,r*2);else{g.fillStyle='#171b22';g.fillRect(-r,-r,r*2,r*2);g.fillStyle='#fff';g.textAlign='center';g.textBaseline='middle';g.font=`900 ${r}px system-ui`;g.fillText((p.username||'?')[0].toUpperCase(),0,2)}g.restore();
  g.strokeStyle=local?'#fff':'#72f5ad';g.lineWidth=local?4:2;g.beginPath();g.arc(0,0,r,0,Math.PI*2);g.stroke();g.restore();
}
function drawMap(g,me,scale,w,h){
  const tile=snapshot.tileSize||64,viewW=w/scale,viewH=h/scale,minX=Math.max(0,Math.floor((me.x-viewW/2)/tile)-1),maxX=Math.min(snapshot.tiles[0].length-1,Math.ceil((me.x+viewW/2)/tile)+1),minY=Math.max(0,Math.floor((me.y-viewH/2)/tile)-1),maxY=Math.min(snapshot.tiles.length-1,Math.ceil((me.y+viewH/2)/tile)+1);
  g.fillStyle='#0a0e14';g.fillRect(0,0,w,h);
  for(let y=minY;y<=maxY;y++)for(let x=minX;x<=maxX;x++){
    const wall=snapshot.tiles[y][x]==='#',hash=Math.abs(x*31+y*17+(snapshot.level||1)*13);
    const key=wall?(hash%5===0?'wall2':'wall'):(hash%3===0?'floor2':hash%3===1?'floor3':'floor');
    const im=images.get(key),s=worldToScreen(x*tile,y*tile,me.x,me.y,scale,w,h),sz=tile*scale;
    if(im?.complete&&im.naturalWidth)g.drawImage(im,s.x,s.y,sz+1,sz+1);
    else{g.fillStyle=wall?'#273141':'#171e27';g.fillRect(s.x,s.y,sz+1,sz+1)}
  }
}
function drawIcon(g,key,o,me,scale,w,h,size=34){const s=worldToScreen(o.x,o.y,me.x,me.y,scale,w,h),im=images.get(key),px=size*Math.min(2,devicePixelRatio||1);if(im?.complete&&im.naturalWidth)g.drawImage(im,s.x-px/2,s.y-px/2,px,px);else{g.fillStyle='#fff';g.fillRect(s.x-6,s.y-6,12,12)}return s}
function renderFrame(t){
  raf=requestAnimationFrame(renderFrame);if(!snapshot||$('#deadSignalStage').classList.contains('hidden')||!$('#view-games').classList.contains('active'))return;resizeCanvas();const c=canvas(),g=ctx();if(!g)return;const w=c.width,h=c.height,dpr=Math.min(2,devicePixelRatio||1);g.imageSmoothingEnabled=false;
  const meServer=snapshot.players.find(p=>p.id===state.user?.id)||snapshot.players[0];if(!meServer)return;for(const p of snapshot.players){const cur=displayPlayers.get(p.id)||{x:p.x,y:p.y};cur.x+=(p.x-cur.x)*.28;cur.y+=(p.y-cur.y)*.28;displayPlayers.set(p.id,cur)}const mePos=displayPlayers.get(meServer.id)||meServer,cam={...meServer,x:mePos.x,y:mePos.y},scale=Math.min(w/(980*dpr),h/(610*dpr))*dpr;
  drawMap(g,cam,scale,w,h);g.imageSmoothingEnabled=true;
  const ex={x:snapshot.exit.x,y:snapshot.exit.y};const exs=drawIcon(g,'exit',ex,cam,scale,w,h,60);g.fillStyle=snapshot.exitOpen?'#76ffae':'#ff5d8f';g.font=`900 ${12*dpr}px system-ui`;g.textAlign='center';g.fillText(snapshot.exitOpen?'EXIT OPEN':'LOCKED',exs.x,exs.y+48*dpr);
  for(const t0 of snapshot.terminals||[]){const s=drawIcon(g,'terminal',t0,cam,scale,w,h,44);if(t0.active){g.strokeStyle='#73ffab';g.lineWidth=3;g.strokeRect(s.x-20*dpr,s.y-20*dpr,40*dpr,40*dpr)}}
  for(const core of snapshot.cores||[])if(!core.collected)drawIcon(g,'core',core,cam,scale,w,h,36);
  for(const item of snapshot.loot||[])drawIcon(g,item.type,item,cam,scale,w,h,31);
  for(const wp of snapshot.weaponPickups||[])if(!wp.collected)drawIcon(g,wp.weapon,wp,cam,scale,w,h,38);
  for(const e of snapshot.enemies||[]){const s=drawIcon(g,'enemy',e,cam,scale,w,h,44),ratio=Math.max(0,e.hp/e.maxHp);g.fillStyle='#2a1218';g.fillRect(s.x-20*dpr,s.y-30*dpr,40*dpr,4*dpr);g.fillStyle='#ff486e';g.fillRect(s.x-20*dpr,s.y-30*dpr,40*dpr*ratio,4*dpr)}
  for(const p of snapshot.players){const pos=displayPlayers.get(p.id)||p,s=worldToScreen(pos.x,pos.y,cam.x,cam.y,scale,w,h);drawPfpCharacter(g,p,s.x,s.y,26*dpr,p.id===state.user.id);g.fillStyle='#fff';g.font=`700 ${10*dpr}px system-ui`;g.textAlign='center';g.fillText(p.username,s.x,s.y-27*dpr)}
  const now=performance.now();effects=effects.filter(e=>now-e.at<220);for(const e of effects){const a=1-(now-e.at)/220,s1=worldToScreen(e.x1,e.y1,cam.x,cam.y,scale,w,h),s2=worldToScreen(e.x2,e.y2,cam.x,cam.y,scale,w,h);g.globalAlpha=a;g.strokeStyle=e.weapon==='signal-sword'?'#ff55da':'#71efff';g.lineWidth=(e.weapon==='signal-sword'?6:2)*dpr;g.beginPath();g.moveTo(s1.x,s1.y);g.lineTo(s2.x,s2.y);g.stroke();g.globalAlpha=1}
  updateInteractPrompt(meServer);
}
function nearInteractable(me){const groups=[[(o)=>`GRAB ${o.name?.toUpperCase()||'LOOT'} · ${money(o.value)}`,snapshot.loot||[]],[(o)=>`EQUIP ${(WEAPON_NAMES[o.weapon]||o.weapon).toUpperCase()}`,(snapshot.weaponPickups||[]).filter(x=>!x.collected)],[(o)=>'USE TERMINAL',(snapshot.terminals||[]).filter(x=>!x.active)],[(o)=>'RECOVER SIGNAL CORE',(snapshot.cores||[]).filter(x=>!x.collected)]];let best=null;for(const [labelFn,list] of groups)for(const o of list){const d=Math.hypot(me.x-o.x,me.y-o.y);if(d<78&&(!best||d<best.d))best={label:labelFn(o),d}}return best}
function updateInteractPrompt(me){const n=nearInteractable(me),el=$('#dsInteractPrompt');el.classList.toggle('hidden',!n);if(n)el.textContent=`E · ${n.label}`}
function renderHUD(){
  if(!snapshot)return;const me=snapshot.players.find(p=>p.id===state.user?.id);if(!me)return;$('#dsLevel').textContent=`LEVEL ${snapshot.level}`;$('#dsTimer').textContent=`${Math.floor(snapshot.timeLeft/60)}:${String(snapshot.timeLeft%60).padStart(2,'0')}`;$('#dsBackpack').textContent=`Bag ${me.backpackCount}/${me.backpackCapacity}`;$('#dsCash').textContent=money(me.cash);$('#dsWeapon').textContent=WEAPON_NAMES[me.weapon]||me.weapon;
  const hp=Math.max(0,Math.min(1,me.health/me.maxHealth)),st=Math.max(0,Math.min(1,me.stamina/me.maxStamina));$('#dsHealthFill').style.width=`${hp*100}%`;$('#dsHealthText').textContent=`${Math.ceil(me.health)} / ${Math.ceil(me.maxHealth)}`;$('#dsStaminaFill').style.width=`${st*100}%`;$('#dsStaminaText').textContent=`${Math.ceil(me.stamina)} / ${Math.ceil(me.maxStamina)}`;
  const box=$('#dsTaskList');box.innerHTML='';for(const t of snapshot.tasks||[]){const done=t.progress>=t.target,row=document.createElement('div');row.className='ds-task-row'+(done?' done':'');row.innerHTML=`<span>${done?'✓':'○'} ${esc(t.label)}</span><b>${t.progress}/${t.target}</b>`;box.appendChild(row)}if(snapshot.exitOpen){const row=document.createElement('div');row.className='ds-task-row exit-ready';row.innerHTML='<span>→ Get the whole squad to EXIT</span><b>OPEN</b>';box.appendChild(row)}
}
function updateState(s){if(!s||!lobby||s.lobbyId!==lobby.id)return;snapshot=s;if(s.status==='running'){setGameMode('running');renderHUD()}}
function addAttackEffect(data){if(!lobby||data.lobbyId!==lobby.id)return;effects.push({...data,at:performance.now()})}

function setupJoystick(){const area=$('#dsJoystick'),knob=$('#dsJoystickKnob');if(!area)return;const move=e=>{if(joystickPointer!==e.pointerId)return;const r=area.getBoundingClientRect(),cx=r.left+r.width/2,cy=r.top+r.height/2,dx=e.clientX-cx,dy=e.clientY-cy,max=r.width*.32,m=Math.hypot(dx,dy)||1,k=Math.min(1,max/m);knob.style.transform=`translate(${dx*k}px,${dy*k}px)`;input.x=dx/m*Math.min(1,m/max);input.y=dy/m*Math.min(1,m/max)};area.addEventListener('pointerdown',e=>{joystickPointer=e.pointerId;area.setPointerCapture(e.pointerId);move(e)});area.addEventListener('pointermove',move);const end=e=>{if(joystickPointer!==e.pointerId)return;joystickPointer=null;input.x=input.y=0;knob.style.transform='translate(0,0)';keysToInput()};area.addEventListener('pointerup',end);area.addEventListener('pointercancel',end)}
function setupCombatControls(){
  const c=canvas();c.addEventListener('pointermove',e=>{const r=c.getBoundingClientRect(),dx=e.clientX-(r.left+r.width/2),dy=e.clientY-(r.top+r.height/2),m=Math.hypot(dx,dy)||1;aim={x:dx/m,y:dy/m}});c.addEventListener('pointerdown',e=>{if(e.pointerType==='mouse'&&e.button===0)attack(false)});
  $('#dsAttackBtn').onclick=()=>attack(true);$('#dsInteractBtn').onclick=interact;
  const sprint=$('#dsSprintBtn');const on=e=>{e.preventDefault();mobileSprint=true;keysToInput()};const off=e=>{e.preventDefault();mobileSprint=false;keysToInput()};sprint.addEventListener('pointerdown',on);sprint.addEventListener('pointerup',off);sprint.addEventListener('pointercancel',off);sprint.addEventListener('pointerleave',e=>{if(e.buttons===0)off(e)});
}

export function initGame(){
  $('#dsOpenGame').onclick=()=>setGameMode('hub');$('#dsBackToGames').onclick=()=>setGameMode('library');$('#dsCreateLobby').onclick=createLobby;$('#dsJoinBtn').onclick=joinCode;$('#dsJoinCode').onkeydown=e=>{if(e.key==='Enter'){e.preventDefault();joinCode()}};
  $('#dsReadyBtn').onclick=toggleReady;$('#dsStartBtn').onclick=startGame;$('#dsNextLevelBtn').onclick=startGame;$('#dsLeaveBtn').onclick=leaveLobby;$('#dsIntermissionLeave').onclick=leaveLobby;$('#dsExitRound').onclick=leaveLobby;$('#dsSellBtn').onclick=sellLoot;$('#dsSellBtnLobby').onclick=sellLoot;
  $('#dsInviteAccept').onclick=()=>respondInvite('accept');$('#dsInviteDecline').onclick=()=>respondInvite('decline');$('#dsGameChatForm').onsubmit=e=>{e.preventDefault();const i=$('#dsGameChatInput'),text=i.value;i.value='';sendGameChat(text)};$('#dsChatToggle').onclick=()=>{chatCollapsed=!chatCollapsed;$('#dsGameChat').classList.toggle('collapsed',chatCollapsed);$('#dsChatToggle').textContent=chatCollapsed?'+':'−'};
  setupJoystick();setupCombatControls();addEventListener('resize',resizeCanvas);
  addEventListener('keydown',e=>{if(['INPUT','TEXTAREA'].includes(document.activeElement?.tagName))return;keyboard[e.code]=true;if(e.code==='KeyE'){e.preventDefault();interact()}if(e.code==='Space'){e.preventDefault();attack(true)}keysToInput()});addEventListener('keyup',e=>{keyboard[e.code]=false;keysToInput()});addEventListener('blur',()=>{keyboard={};mobileSprint=false;if(joystickPointer===null)input={x:0,y:0,sprint:false}});
  window.addEventListener('nexo:game-invite',e=>showInvite(e.detail));window.addEventListener('nexo:game-lobby',e=>{lobby=e.detail.lobby;renderLobby();renderChatMessages()});window.addEventListener('nexo:game-state',e=>updateState(e.detail));window.addEventListener('nexo:game-end',e=>showLevelResult(e.detail));window.addEventListener('nexo:game-level-complete',e=>showLevelResult(e.detail));window.addEventListener('nexo:game-attack',e=>addAttackEffect(e.detail));window.addEventListener('nexo:game-chat',e=>appendGameChat(e.detail));window.addEventListener('nexo:friends',()=>lobby&&renderInviteFriends());window.addEventListener('nexo:login',()=>{loadProfile();loadStatus()});window.addEventListener('nexo:shown',e=>{if(e.detail==='games'){loadProfile();loadStatus()}else{keyboard={};mobileSprint=false;if(joystickPointer===null)input={x:0,y:0,sprint:false};sendInput()}});
  raf=requestAnimationFrame(renderFrame);setGameMode('library');loadProfile();loadStatus();
}
