import{$,esc,avatar,time,toast}from'./ui.js';
import{api}from'./api.js';
import{state}from'./state.js';
import{openProfile}from'./profile.js';

let tab='friends',active=null,activeChannel=null;
const renderedMessageIds=new Set();

function sidebar(){
  const box=$('#chatSidebar');
  box.innerHTML='';
  if(tab==='friends'){
    state.friends.forEach(u=>{
      const e=document.createElement('button');
      e.className='chat-entry'+(active?.type==='dm'&&active.username===u.username?' active':'');
      e.innerHTML=`${avatar(u)}<span>${esc(u.username)}</span>`;
      e.onclick=()=>openDM(u.username);
      box.appendChild(e);
    });
  }else{
    state.groups.forEach(g=>{
      const e=document.createElement('button');
      e.className='chat-entry'+(active?.type==='group'&&active.id===g.id?' active':'');
      e.innerHTML=`<div class="avatar-fallback">#</div><span>${esc(g.name)}</span>`;
      e.onclick=()=>openGroup(g.id);
      box.appendChild(e);
    });
  }
}

async function loadGroups(){
  try{
    state.groups=(await api('/api/groups')).groups||[];
    sidebar();
  }catch(e){console.error(e)}
}

function makeMessage(m){
  const mine=m.fromId===state.user.id;
  const e=document.createElement('div');
  e.className='message'+(mine?' mine':'');
  e.dataset.messageId=m.id||'';
  e.innerHTML=`${m.pfp?`<img class="avatar" src="${esc(m.pfp)}">`:`<div class="avatar-fallback">${esc((m.from||'?')[0])}</div>`}<div class="bubble"><div>${esc(m.body)}</div><div class="bubble-time">${time(m.createdAt)}</div></div>`;
  return e;
}

function renderMessages(messages){
  const b=$('#messageList');
  b.innerHTML='';
  renderedMessageIds.clear();
  messages.forEach(m=>{
    if(m.id)renderedMessageIds.add(m.id);
    b.appendChild(makeMessage(m));
  });
  requestAnimationFrame(()=>b.scrollTop=b.scrollHeight);
}

function append(m){
  if(!m)return;
  if(m.id&&renderedMessageIds.has(m.id))return;
  if(m.id)renderedMessageIds.add(m.id);
  const b=$('#messageList');
  b.appendChild(makeMessage(m));
  requestAnimationFrame(()=>b.scrollTop=b.scrollHeight);
}

export async function openDM(username){
  try{
    const d=await api('/api/dms/'+encodeURIComponent(username));
    active={type:'dm',username,user:d.user};
    activeChannel=null;
    state.activeConversation=active;
    $('#chatEmpty').classList.add('hidden');
    $('#conversation').classList.remove('hidden');
    $('#channelStrip').classList.add('hidden');
    $('#conversationHeader').innerHTML=`${avatar(d.user)}<div><b>${esc(d.user.username)}</b><div class="muted small">${d.user.online?'Online':'Offline'}</div></div><button id="dmProfile" class="secondary" style="margin-left:auto">Profile</button>`;
    $('#dmProfile').onclick=()=>openProfile(username);
    renderMessages(d.messages);
    sidebar();
    setComposerEnabled(true);
  }catch(e){toast(e.message)}
}

async function openGroup(id){
  try{
    const d=await api('/api/groups/'+id);
    active={type:'group',id,group:d.group,channels:d.channels,members:d.members};
    activeChannel=null;
    state.activeConversation=active;
    $('#chatEmpty').classList.add('hidden');
    $('#conversation').classList.remove('hidden');
    $('#conversationHeader').innerHTML=`<div class="avatar-fallback">#</div><div><b>${esc(d.group.name)}</b><div class="muted small">${d.members.length} members</div></div>${d.members.find(x=>x.id===state.user.id)?.role!=='member'?'<button id="addChannel" class="secondary" style="margin-left:auto">+ Channel</button>':''}`;
    $('#chatInfo').innerHTML=`<b>Members</b><div>${d.members.map(x=>esc(x.username)).join('<br>')}</div>${d.members.find(x=>x.id===state.user.id)?.role!=='member'?'<button id="addMember" class="secondary" style="margin-top:10px">Add Friend</button>':''}`;
    $('#channelStrip').classList.remove('hidden');
    $('#channelStrip').innerHTML='';
    d.channels.forEach(c=>{
      const b=document.createElement('button');
      b.textContent='# '+c.name;
      b.dataset.channelId=c.id;
      b.onclick=()=>openChannel(c.id);
      $('#channelStrip').appendChild(b);
    });
    $('#addChannel')?.addEventListener('click',async()=>{
      const n=prompt('Channel name');
      if(!n)return;
      try{await api(`/api/groups/${id}/channels`,{method:'POST',body:JSON.stringify({name:n})});openGroup(id)}catch(e){toast(e.message)}
    });
    $('#addMember')?.addEventListener('click',async()=>{
      const n=prompt('Friend username');
      if(!n)return;
      try{await api(`/api/groups/${id}/members`,{method:'POST',body:JSON.stringify({username:n})});openGroup(id)}catch(e){toast(e.message)}
    });
    sidebar();
    setComposerEnabled(true);
    if(d.channels[0])openChannel(d.channels[0].id);
  }catch(e){toast(e.message)}
}

async function openChannel(id){
  if(!active||active.type!=='group')return;
  try{
    const d=await api(`/api/channels/${id}/messages`);
    activeChannel=id;
    [...$('#channelStrip').children].forEach(b=>b.classList.toggle('active',b.dataset.channelId===id));
    renderMessages(d.messages);
    setComposerEnabled(true);
  }catch(e){toast(e.message)}
}

function resetComposer(){
  const input=$('#messageInput');
  input.value='';
  input.style.height='44px';
  input.style.overflowY='hidden';
}
function setComposerEnabled(enabled){
  const input=$('#messageInput'),button=$('#messageSendBtn');
  input.disabled=!enabled;
  button.disabled=!enabled;
  input.placeholder=enabled?'Message…':'Choose a conversation first…';
  if(enabled){
    requestAnimationFrame(()=>{
      input.focus({preventScroll:true});
      input.scrollIntoView({block:'nearest'});
    });
  }
}

function resizeComposer(){
  const input=$('#messageInput');
  input.style.height='44px';
  input.style.height=Math.min(input.scrollHeight,112)+'px';
  input.style.overflowY=input.scrollHeight>112?'auto':'hidden';
}

async function send(){
  const input=$('#messageInput');
  const body=input.value.trim();
  if(!body||!active)return;
  resetComposer();
  try{
    if(active.type==='dm'){
      const d=await api('/api/dms/'+encodeURIComponent(active.username),{method:'POST',body:JSON.stringify({body})});
      append(d.message);
    }else if(activeChannel){
      const d=await api(`/api/channels/${activeChannel}/messages`,{method:'POST',body:JSON.stringify({body})});
      append(d.message);
    }
  }catch(e){
    input.value=body;
    resizeComposer();
    toast(e.message);
  }
}

export function initChat(){
  document.querySelectorAll('[data-chat-tab]').forEach(b=>b.onclick=()=>{
    tab=b.dataset.chatTab;
    document.querySelectorAll('[data-chat-tab]').forEach(x=>x.classList.toggle('active',x===b));
    sidebar();
  });
  $('#messageForm').onsubmit=e=>{e.preventDefault();send()};
  $('#messageInput').addEventListener('input',resizeComposer);
  $('#messageInput').onkeydown=e=>{
    if(e.key==='Enter'&&!e.shiftKey){e.preventDefault();send()}
  };
  resizeComposer();
  setComposerEnabled(false);
  $('#messageInput').addEventListener('focus',()=>requestAnimationFrame(()=>$('#messageInput').scrollIntoView({block:'nearest'})));
  $('#newGroupBtn').onclick=()=>$('#groupOverlay').classList.remove('hidden');
  $('#groupCancel').onclick=()=>$('#groupOverlay').classList.add('hidden');
  $('#groupForm').onsubmit=async e=>{
    e.preventDefault();
    try{
      const d=await api('/api/groups',{method:'POST',body:JSON.stringify({name:$('#groupName').value})});
      $('#groupOverlay').classList.add('hidden');
      $('#groupName').value='';
      await loadGroups();
      tab='groups';
      document.querySelectorAll('[data-chat-tab]').forEach(x=>x.classList.toggle('active',x.dataset.chatTab==='groups'));
      openGroup(d.groupId);
    }catch(x){toast(x.message)}
  };
  window.addEventListener('nexo:friends',sidebar);
  window.addEventListener('nexo:opendm',e=>{window.dispatchEvent(new CustomEvent('nexo:view',{detail:'chat'}));openDM(e.detail)});
  window.addEventListener('nexo:group',()=>loadGroups());
  window.addEventListener('nexo:dm',e=>{
    const m=e.detail.message;
    if(active?.type==='dm'&&(m.from===active.username||m.fromId===state.user.id))append(m);
  });
  window.addEventListener('nexo:channel',e=>{if(activeChannel===e.detail.channelId)append(e.detail)});
  loadGroups();
}
