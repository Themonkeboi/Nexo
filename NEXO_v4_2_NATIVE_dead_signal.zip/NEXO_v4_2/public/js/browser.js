import{$,esc}from'./ui.js';

const tabs=[];
let active=null;

const viewTitles={
  home:'Home',
  games:'Games',
  music:'Music',
  social:'People',
  chat:'Chat',
  settings:'Settings'
};

function current(){return tabs.find(x=>x.id===active)}
function looksUrl(v){return /^https?:\/\//i.test(v)||/^[a-z0-9.-]+\.[a-z]{2,}(\/.*)?$/i.test(v)}
function target(v){
  v=String(v||'').trim();
  if(!v)return'';
  if(/^javascript:|^data:|^file:/i.test(v))return'';
  return looksUrl(v)
    ? (/^https?:\/\//i.test(v)?v:'https://'+v)
    : 'https://www.bing.com/search?q='+encodeURIComponent(v)
}
function webTitle(v){
  if(!v)return'New Tab';
  if(!looksUrl(v))return v.length>22?v.slice(0,22)+'…':v;
  try{return new URL(/^https?:/i.test(v)?v:'https://'+v).hostname.replace(/^www\./,'')}
  catch{return'Page'}
}
function panel(id){return document.querySelector(`.browser-panel[data-id="${id}"]`)}
function ensurePanel(t){
  let p=panel(t.id);
  if(!p){
    p=document.createElement('div');
    p.className='browser-panel';
    p.dataset.id=t.id;
    p.innerHTML=`<iframe title="NEXO browser tab"></iframe><div class="browser-help">Some sites block being embedded. NEXO cannot override a site's security settings.</div>`;
    $('#browserPanels').appendChild(p);
  }
  return p;
}
function emitActive(t){
  window.dispatchEvent(new CustomEvent('nexo:tab-activate',{
    detail:t.type==='view'
      ? {type:'view',view:t.view,id:t.id}
      : {type:'web',id:t.id,url:t.url||''}
  }));
}
function activate(){
  const t=current();
  if(!t)return;
  document.querySelectorAll('.browser-panel').forEach(p=>{
    p.classList.toggle('active',t.type==='web'&&p.dataset.id===t.id);
  });
  $('#addressInput').value=t.type==='web'?(t.url||''):`nexo://${t.view}`;
  [...$('#browserTabs').children].forEach((e,i)=>e.classList.toggle('active',tabs[i]?.id===active));
  emitActive(t);
}
function render(){
  const bar=$('#browserTabs');
  bar.innerHTML='';
  tabs.forEach(t=>{
    const e=document.createElement('button');
    e.className='tab'+(t.id===active?' active':'')+(t.type==='view'?' app-tab':'');
    const icon=t.type==='view'
      ? ({home:'⌂',games:'🎮',music:'♫',social:'👥',chat:'✉',settings:'⚙'}[t.view]||'N')
      : '◉';
    e.innerHTML=`<span class="tab-kind">${icon}</span><span class="tab-title">${esc(t.title)}</span><span class="tab-close">×</span>`;
    e.onclick=ev=>{
      if(ev.target.classList.contains('tab-close')){
        ev.stopPropagation();
        close(t.id);
        return;
      }
      active=t.id;
      activate();
    };
    bar.appendChild(e);
  });
  activate();
}
function close(id){
  const i=tabs.findIndex(x=>x.id===id);
  if(i<0)return;
  const wasActive=active===id;
  panel(id)?.remove();
  tabs.splice(i,1);
  if(!tabs.length){
    openWebTab();
    return;
  }
  if(wasActive)active=tabs[Math.min(i,tabs.length-1)].id;
  render();
}
function createWebTab(){
  const t={id:crypto.randomUUID(),type:'web',title:'New Tab',url:'',history:[],index:-1};
  tabs.push(t);
  active=t.id;
  ensurePanel(t).querySelector('iframe').src='about:blank';
  render();
  return t;
}

export function openWebTab(value=''){
  const t=createWebTab();
  if(value)navigate(value,true,t);
  return t;
}

export function openViewTab(view,title=viewTitles[view]||'NEXO'){
  let t=tabs.find(x=>x.type==='view'&&x.view===view);
  if(!t){
    t={id:crypto.randomUUID(),type:'view',view,title};
    tabs.push(t);
  }
  active=t.id;
  render();
  return t;
}

export function navigate(value,add=true,forcedTab=null){
  let t=forcedTab||current();
  if(!t||t.type!=='web')t=createWebTab();
  const u=target(value);
  if(!u)return;
  t.url=u;
  t.title=webTitle(value);
  if(add){
    t.history=t.history.slice(0,t.index+1);
    t.history.push(u);
    t.index=t.history.length-1;
  }
  ensurePanel(t).querySelector('iframe').src=u;
  render();
}

export function initBrowser(){
  $('#newTab').onclick=()=>openWebTab();
  $('#addressForm').onsubmit=e=>{
    e.preventDefault();
    navigate($('#addressInput').value);
  };
  $('#homeSearch').onsubmit=e=>{
    e.preventDefault();
    navigate($('#homeSearchInput').value);
  };
  $('#backBtn').onclick=()=>{
    const t=current();
    if(t?.type==='web'&&t.index>0){
      t.index--;
      t.url=t.history[t.index];
      ensurePanel(t).querySelector('iframe').src=t.url;
      render();
    }
  };
  $('#forwardBtn').onclick=()=>{
    const t=current();
    if(t?.type==='web'&&t.index<t.history.length-1){
      t.index++;
      t.url=t.history[t.index];
      ensurePanel(t).querySelector('iframe').src=t.url;
      render();
    }
  };
  $('#reloadBtn').onclick=()=>{
    const t=current();
    if(t?.type==='web'&&t.url)ensurePanel(t).querySelector('iframe').src=t.url;
  };
}
