import{$,$$}from'./ui.js';
import{state}from'./state.js';
import{initAuth,loadMe}from'./auth.js';
import{initBrowser,openViewTab,openWebTab}from'./browser.js';
import{initProfile}from'./profile.js';
import{initSocial,loadFriends,renderPeople}from'./social.js';
import{initMusic}from'./music.js';
import{initChat}from'./chat.js';
import{initSettings,apply}from'./settings.js';
import{initGame}from'./game.js';


function syncVisualViewport(){
  const h=window.visualViewport?.height||window.innerHeight;
  document.documentElement.style.setProperty('--nexo-visible-height',`${Math.round(h)}px`);
}
syncVisualViewport();
window.addEventListener('resize',syncVisualViewport);
window.visualViewport?.addEventListener('resize',syncVisualViewport);
window.visualViewport?.addEventListener('scroll',syncVisualViewport);

const titles={home:'Home',games:'Games',music:'Music',social:'People',chat:'Chat',settings:'Settings'};

function showOnly(view){
  state.view=view;
  $$('.view').forEach(v=>v.classList.toggle('active',v.id==='view-'+view));
  $$('.rail [data-view]').forEach(b=>b.classList.toggle('active',b.dataset.view===view));
  if(view==='social')renderPeople();
  window.dispatchEvent(new CustomEvent('nexo:shown',{detail:view}));
}

function openSection(view){
  if(view==='browser'){
    openWebTab();
    return;
  }
  openViewTab(view,titles[view]||'NEXO');
}

function events(){
  state.eventSource?.close();
  const es=new EventSource('/api/events');
  state.eventSource=es;
  es.addEventListener('friend_request',()=>loadFriends());
  es.addEventListener('friend_accept',()=>loadFriends());
  es.addEventListener('friend_decline',()=>loadFriends());
  es.addEventListener('dm_message',e=>window.dispatchEvent(new CustomEvent('nexo:dm',{detail:JSON.parse(e.data)})));
  es.addEventListener('channel_message',e=>window.dispatchEvent(new CustomEvent('nexo:channel',{detail:JSON.parse(e.data)})));
  es.addEventListener('group_update',()=>window.dispatchEvent(new Event('nexo:group')));
  es.addEventListener('music_new',()=>window.dispatchEvent(new Event('nexo:music')));
  es.addEventListener('game_invite',e=>window.dispatchEvent(new CustomEvent('nexo:game-invite',{detail:JSON.parse(e.data)})));
  es.addEventListener('game_lobby',e=>window.dispatchEvent(new CustomEvent('nexo:game-lobby',{detail:JSON.parse(e.data)})));
  es.addEventListener('game_state',e=>window.dispatchEvent(new CustomEvent('nexo:game-state',{detail:JSON.parse(e.data)})));
  es.addEventListener('game_end',e=>window.dispatchEvent(new CustomEvent('nexo:game-end',{detail:JSON.parse(e.data)})));
  es.addEventListener('game_chat',e=>window.dispatchEvent(new CustomEvent('nexo:game-chat',{detail:JSON.parse(e.data)})));
  es.addEventListener('game_level_complete',e=>window.dispatchEvent(new CustomEvent('nexo:game-level-complete',{detail:JSON.parse(e.data)})));
  es.addEventListener('game_attack',e=>window.dispatchEvent(new CustomEvent('nexo:game-attack',{detail:JSON.parse(e.data)})));
}

async function afterLogin(){
  await loadFriends();
  events();
  apply();
}

initAuth();
initBrowser();
initProfile();
initSocial();
initMusic();
initChat();
initSettings();
initGame();

window.addEventListener('nexo:tab-activate',e=>{
  showOnly(e.detail.type==='web'?'browser':e.detail.view);
});

$$('.rail [data-view]').forEach(b=>b.onclick=()=>openSection(b.dataset.view));
$$('[data-go]').forEach(b=>b.onclick=()=>openSection(b.dataset.go));
window.addEventListener('nexo:view',e=>openSection(e.detail));
window.addEventListener('nexo:login',afterLogin);

const ok=await loadMe();
if(ok)afterLogin();
openViewTab('home','Home');
